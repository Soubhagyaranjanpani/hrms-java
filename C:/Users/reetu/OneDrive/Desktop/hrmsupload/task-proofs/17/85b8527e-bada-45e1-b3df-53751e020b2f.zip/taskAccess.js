import { STORAGE_KEYS } from '../config/api.config';

const readUserData = () => {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEYS.USER_DATA)) || {}; } catch { return {}; }
};

// Same normalisation your TaskList / TaskDashboard already use -> 'Admin' | 'Hr' | 'Manager' | 'Employee'
export const getNormalizedRole = (currentUser) => {
  try {
    const uData = readUserData();
    const raw = localStorage.getItem(STORAGE_KEYS.ROLE) ||
                localStorage.getItem('roleName') ||
                localStorage.getItem('role') ||
                localStorage.getItem('userRole') ||
                currentUser?.role || currentUser?.roleName || currentUser?.role?.name ||
                uData?.role || uData?.roleName || uData?.role?.name;
    if (raw) {
      let s = typeof raw === 'object' ? (raw.name || raw.roleName || raw.role || '') : String(raw);
      if (s.toUpperCase().startsWith('ROLE_')) s = s.substring(5);
      const up = s.toUpperCase().replace(/[\s_-]+/g, '');
      if (up === 'ADMIN' || up === 'ADMINISTRATOR' || up === 'SUPERADMIN') return 'Admin';
      if (up === 'HR' || up === 'HUMANRESOURCE' || up === 'HUMANRESOURCES' || up === 'HROFFICER' || up === 'HRMANAGER') return 'Hr';
      if (up === 'MANAGER') return 'Manager';
      return 'Employee';
    }
  } catch {}
  return 'Employee';
};

// Logged-in employee id (saved by your Login page)
export const getMyId = (currentUser) => {
  const u = readUserData();
  return localStorage.getItem(STORAGE_KEYS.EMPLOYEE_ID) ||
         currentUser?.id || currentUser?.employeeId || u.id || u.employeeId || '';
};
