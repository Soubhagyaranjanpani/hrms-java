import React, { useState, useEffect, useMemo } from 'react';
import { FaChartLine } from 'react-icons/fa';
import { API_ENDPOINTS, getAuthHeaders } from '../config/api.config';
import { toast } from '../components/Toast';

const fmt = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const cleanName = (n) => (n || '').replace(/\s+null\s*/gi, '').trim();

/**
 * Daily submissions graph (no chart library needed).
 *  Employee            -> GET /api/progress/me
 *  Manager / Admin / HR -> GET /api/progress/team  (backend already limits who you can see)
 */
export default function TaskProgressChart({ isEmployee }) {
  const [days, setDays] = useState(14);
  const [deptId, setDeptId] = useState('');
  const [people, setPeople] = useState([]);
  const [selected, setSelected] = useState('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const to = new Date();
    const from = new Date(); from.setDate(to.getDate() - (days - 1));
    const q = new URLSearchParams({ from: fmt(from), to: fmt(to) });
    if (!isEmployee && deptId) q.set('departmentId', deptId);
    const url = `${isEmployee ? API_ENDPOINTS.PROGRESS_ME : API_ENDPOINTS.PROGRESS_TEAM}?${q}`;

    setLoading(true);
    fetch(url, { headers: getAuthHeaders() })
      .then(async (res) => {
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || `HTTP ${res.status}`);
        const body = data.response ?? data.data ?? data;
        setPeople(Array.isArray(body) ? body : body ? [body] : []);
        setSelected('all');
      })
      .catch((err) => { toast.error('Progress', err.message || 'Could not load progress'); setPeople([]); })
      .finally(() => setLoading(false));
  }, [days, deptId, isEmployee]);

  const departments = useMemo(() => {
    const m = new Map();
    people.forEach(p => p.departmentId && m.set(p.departmentId, p.department));
    return [...m.entries()];
  }, [people]);

  const shown = selected === 'all' ? people : people.filter(p => String(p.employeeId) === selected);

  // one row per day: sum of everyone shown
  const daily = useMemo(() => {
    if (!shown.length) return [];
    return shown[0].daily.map((d, i) => ({
      date: d.date,
      submissions: shown.reduce((s, p) => s + (p.daily[i]?.submissions || 0), 0),
      approved: shown.reduce((s, p) => s + (p.daily[i]?.approved || 0), 0),
    }));
  }, [shown]);

  const max = Math.max(1, ...daily.map(d => d.submissions));
  const total = shown.reduce((s, p) => s + (p.totalSubmissions || 0), 0);
  const avgDaily = shown.length ? (shown.reduce((s, p) => s + (p.avgDailySubmissions || 0), 0) / shown.length).toFixed(2) : '0';
  const approved = shown.reduce((s, p) => s + (p.approvedSubmissions || 0), 0);
  const late = shown.reduce((s, p) => s + (p.lateSubmissions || 0), 0);

  const sel = { padding: '5px 9px', border: '1.5px solid var(--border-medium)', borderRadius: 8, fontSize: 11, background: 'var(--bg-white)', color: 'var(--text-primary)' };

  return (
    <div style={{ background: 'var(--card-bg)', border: '1px solid var(--border-light)', borderRadius: 14, overflow: 'hidden', marginBottom: 16 }}>
      <div style={{ padding: '10px 14px', borderBottom: '1px solid var(--border-light)', background: 'var(--bg-surface)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
        <h3 style={{ margin: 0, fontSize: 13, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 6 }}>
          <FaChartLine size={12} color="var(--accent-indigo)" /> {isEmployee ? 'My Daily Progress' : 'Employee Daily Progress'}
        </h3>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {!isEmployee && departments.length > 1 && (
            <select style={sel} value={deptId} onChange={e => setDeptId(e.target.value)}>
              <option value="">All departments</option>
              {departments.map(([id, name]) => <option key={id} value={id}>{name}</option>)}
            </select>
          )}
          {!isEmployee && people.length > 1 && (
            <select style={sel} value={selected} onChange={e => setSelected(e.target.value)}>
              <option value="all">All employees</option>
              {people.map(p => <option key={p.employeeId} value={p.employeeId}>{cleanName(p.employeeName)}</option>)}
            </select>
          )}
          <select style={sel} value={days} onChange={e => setDays(Number(e.target.value))}>
            <option value={7}>Last 7 days</option>
            <option value={14}>Last 14 days</option>
            <option value={30}>Last 30 days</option>
          </select>
        </div>
      </div>

      <div style={{ padding: 14 }}>
        {loading ? (
          <p style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: 12 }}>Loading…</p>
        ) : people.length === 0 ? (
          <p style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: 12 }}>No progress data.</p>
        ) : (
          <>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 10, marginBottom: 14 }}>
              {[['Total submissions', total], ['Avg per day', avgDaily], ['Approved', approved], ['Late', late]].map(([l, v]) => (
                <div key={l} style={{ textAlign: 'center', background: 'var(--bg-surface)', borderRadius: 10, padding: '8px 4px' }}>
                  <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>{l}</div>
                  <div style={{ fontSize: 20, fontWeight: 700, fontFamily: "'Sora',sans-serif" }}>{v}</div>
                </div>
              ))}
            </div>

            <div style={{ display: 'flex', alignItems: 'flex-end', gap: 4, height: 120, borderBottom: '1px solid var(--border-light)' }}>
              {daily.map(d => (
                <div key={d.date} title={`${d.date}: ${d.submissions} submitted, ${d.approved} approved`} style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', height: '100%' }}>
                  <div style={{ height: `${(d.submissions / max) * 100}%`, minHeight: d.submissions ? 3 : 0, background: 'var(--accent-indigo)', borderRadius: '4px 4px 0 0', display: 'flex', alignItems: 'flex-end', overflow: 'hidden' }}>
                    <div style={{ width: '100%', height: `${d.submissions ? (d.approved / d.submissions) * 100 : 0}%`, background: '#10b981' }} />
                  </div>
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 4, marginTop: 3 }}>
              {daily.map((d, i) => (
                <div key={d.date} style={{ flex: 1, textAlign: 'center', fontSize: 9, color: 'var(--text-muted)' }}>
                  {days <= 14 || i % 3 === 0 ? d.date.slice(5) : ''}
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 14, marginTop: 8, fontSize: 10, color: 'var(--text-muted)' }}>
              <span><span style={{ display: 'inline-block', width: 8, height: 8, background: 'var(--accent-indigo)', borderRadius: 2, marginRight: 4 }} />Submitted</span>
              <span><span style={{ display: 'inline-block', width: 8, height: 8, background: '#10b981', borderRadius: 2, marginRight: 4 }} />Approved</span>
            </div>

            {!isEmployee && (
              <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: 14, fontSize: 12 }}>
                <thead>
                  <tr style={{ background: 'var(--bg-surface)' }}>
                    {['Employee', 'Department', 'Submissions', 'Avg / day', 'Active days', 'Completed tasks', 'Overdue'].map(h => (
                      <th key={h} style={{ padding: '6px 8px', textAlign: 'left', fontSize: 10, color: 'var(--accent-indigo)', textTransform: 'uppercase' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {people.map(p => (
                    <tr key={p.employeeId} onClick={() => setSelected(String(p.employeeId))} style={{ cursor: 'pointer', background: String(p.employeeId) === selected ? '#f5f3ff' : 'transparent' }}>
                      <td style={{ padding: '6px 8px', borderBottom: '1px solid #f0f2f9', fontWeight: 600 }}>{cleanName(p.employeeName)}</td>
                      <td style={{ padding: '6px 8px', borderBottom: '1px solid #f0f2f9' }}>{p.department || '—'}</td>
                      <td style={{ padding: '6px 8px', borderBottom: '1px solid #f0f2f9' }}>{p.totalSubmissions}</td>
                      <td style={{ padding: '6px 8px', borderBottom: '1px solid #f0f2f9' }}>{p.avgDailySubmissions}</td>
                      <td style={{ padding: '6px 8px', borderBottom: '1px solid #f0f2f9' }}>{p.activeDays}</td>
                      <td style={{ padding: '6px 8px', borderBottom: '1px solid #f0f2f9' }}>{p.taskStats?.completed ?? 0}</td>
                      <td style={{ padding: '6px 8px', borderBottom: '1px solid #f0f2f9', color: (p.taskStats?.overdue || 0) > 0 ? '#ef4444' : 'inherit' }}>{p.taskStats?.overdue ?? 0}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </>
        )}
      </div>
    </div>
  );
}
