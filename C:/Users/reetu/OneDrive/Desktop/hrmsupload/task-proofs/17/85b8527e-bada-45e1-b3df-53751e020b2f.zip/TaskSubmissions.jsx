import React, { useState, useEffect, useCallback } from 'react';
import { FaPaperclip, FaDownload, FaCheck, FaTimes, FaUpload } from 'react-icons/fa';
import { API_ENDPOINTS, STORAGE_KEYS, getAuthHeaders } from '../config/api.config';
import { toast } from '../components/Toast';

// multipart request: do NOT send Content-Type (browser sets the boundary)
const authOnly = () => ({ Authorization: `Bearer ${localStorage.getItem(STORAGE_KEYS.JWT_TOKEN)}` });
const unwrap = (d) => d?.response ?? d?.data ?? d;

const SUB_COLORS = {
  SUBMITTED: ['#fef3c7', '#92400e'],
  APPROVED:  ['#dcfce7', '#166534'],
  REJECTED:  ['#fee2e2', '#991b1b'],
};

async function postReview(submissionId, approved, comment) {
  const res = await fetch(API_ENDPOINTS.REVIEW_SUBMISSION(submissionId), {
    method: 'POST', headers: getAuthHeaders(), body: JSON.stringify({ approved, comment }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || `Review failed (HTTP ${res.status})`);
  return data;
}

// Used by the IN_REVIEW banner: approve / reject the newest pending FINAL submission
export async function reviewLatest(taskId, approved, comment = '') {
  const res = await fetch(API_ENDPOINTS.GET_SUBMISSIONS(taskId), { headers: getAuthHeaders() });
  const list = unwrap(await res.json());
  const pending = (Array.isArray(list) ? list : []).find(s => s.status === 'SUBMITTED' && s.finalSubmission);
  if (!pending) return false;           // no submission (old task) -> caller falls back to old status call
  await postReview(pending.id, approved, comment);
  return true;
}

/* ───────────────── Employee: "Submit Work" modal ───────────────── */
export function SubmitWorkModal({ task, onClose, onDone }) {
  const [form, setForm] = useState({
    progress: task?.progress || 0, hoursSpent: '', note: '', proofLink: '', finalSubmission: false,
  });
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const submit = async () => {
    const p = Number(form.progress);
    if (isNaN(p) || p < 0 || p > 100) return toast.warning('Validation', 'Progress must be 0 to 100');
    const hasProof = !!file || !!form.proofLink.trim();
    if (form.finalSubmission && !hasProof) return toast.warning('Proof required', 'Attach a file or a link for final submission');
    if (!hasProof && !form.note.trim()) return toast.warning('Validation', 'Add a note or proof');

    const fd = new FormData();
    fd.append('progress', form.finalSubmission ? 100 : p);
    fd.append('finalSubmission', form.finalSubmission);
    if (form.hoursSpent !== '') fd.append('hoursSpent', form.hoursSpent);
    if (form.note.trim())      fd.append('note', form.note.trim());
    if (form.proofLink.trim()) fd.append('proofLink', form.proofLink.trim());
    if (file)                  fd.append('file', file);

    setBusy(true);
    try {
      const res = await fetch(API_ENDPOINTS.SUBMIT_PROOF(task.id), { method: 'POST', headers: authOnly(), body: fd });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.message || `Submit failed (HTTP ${res.status})`);
      toast.success('Submitted', form.finalSubmission ? 'Sent to manager for review' : 'Daily progress saved');
      onDone?.();
      onClose();
    } catch (err) {
      toast.error('Error', err.message);
    } finally {
      setBusy(false);
    }
  };

  const inp = { width: '100%', padding: '9px 12px', border: '1.5px solid var(--border-medium)', borderRadius: 10, fontSize: 13.5, fontFamily: "'DM Sans',sans-serif", background: 'var(--bg-surface)', color: 'var(--text-primary)', outline: 'none' };
  const lbl = { fontSize: 13, fontWeight: 600, color: 'var(--text-secondary)', display: 'block', marginBottom: 5 };

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <div style={{ padding: '20px 24px 16px', borderBottom: '1px solid var(--border-light)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h3 style={{ margin: 0, fontSize: 17, fontWeight: 700 }}>📤 Submit Work</h3>
          <button onClick={onClose} style={{ background: 'var(--bg-surface)', border: 'none', width: 32, height: 32, borderRadius: 8, cursor: 'pointer' }}>✕</button>
        </div>
        <div style={{ padding: '18px 24px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <div>
            <label style={lbl}>Progress % <span style={{ color: 'var(--danger)' }}>*</span></label>
            <input type="number" min="0" max="100" style={inp} value={form.finalSubmission ? 100 : form.progress} disabled={form.finalSubmission} onChange={e => set('progress', e.target.value)} />
          </div>
          <div>
            <label style={lbl}>Hours spent today</label>
            <input type="number" min="0" max="24" step="0.5" style={inp} value={form.hoursSpent} onChange={e => set('hoursSpent', e.target.value)} />
          </div>
          <div style={{ gridColumn: 'span 2' }}>
            <label style={lbl}>What did you do?</label>
            <textarea rows={3} style={{ ...inp, resize: 'vertical' }} value={form.note} onChange={e => set('note', e.target.value)} placeholder="Short update / work done…" />
          </div>
          <div style={{ gridColumn: 'span 2' }}>
            <label style={lbl}>Proof link (optional)</label>
            <input type="text" style={inp} value={form.proofLink} onChange={e => set('proofLink', e.target.value)} placeholder="https://…" />
          </div>
          <div style={{ gridColumn: 'span 2' }}>
            <label style={lbl}>Proof file (pdf, png, jpg, doc, xls, txt, zip — max 10 MB)</label>
            <input type="file" accept=".pdf,.png,.jpg,.jpeg,.doc,.docx,.xls,.xlsx,.txt,.zip" onChange={e => setFile(e.target.files?.[0] || null)} />
          </div>
          <label style={{ gridColumn: 'span 2', display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, fontWeight: 600, color: '#5b21b6', background: '#f3e8ff', padding: '9px 12px', borderRadius: 10, cursor: 'pointer' }}>
            <input type="checkbox" checked={form.finalSubmission} onChange={e => set('finalSubmission', e.target.checked)} />
            This is the FINAL submission (task is complete, send to manager for approval)
          </label>
        </div>
        <div style={{ padding: '14px 24px', borderTop: '1px solid var(--border-light)', background: 'var(--bg-surface)', display: 'flex', justifyContent: 'flex-end', gap: 10, borderRadius: '0 0 22px 22px' }}>
          <button onClick={onClose} style={{ background: 'var(--bg-white)', border: '1.5px solid var(--border-medium)', padding: '9px 18px', borderRadius: 10, fontSize: 13, cursor: 'pointer' }}>Cancel</button>
          <button onClick={submit} disabled={busy} style={{ background: 'linear-gradient(135deg,var(--accent-indigo),var(--accent-indigo-light))', border: 'none', color: '#fff', padding: '9px 20px', borderRadius: 10, fontWeight: 600, fontSize: 13, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6, opacity: busy ? .7 : 1 }}>
            <FaUpload size={11} /> {busy ? 'Submitting…' : 'Submit'}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ───────────────── "Submissions" tab: history + manager review ───────────────── */
export default function SubmissionsPanel({ taskId, canReview, refreshKey = 0, onChanged }) {
  const [list, setList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState(null);

  const load = useCallback(async () => {
    try {
      const res = await fetch(API_ENDPOINTS.GET_SUBMISSIONS(taskId), { headers: getAuthHeaders() });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Could not load submissions');
      const arr = unwrap(data);
      setList(Array.isArray(arr) ? arr : []);
    } catch (err) {
      toast.error('Error', err.message);
    } finally {
      setLoading(false);
    }
  }, [taskId]);

  useEffect(() => { load(); }, [load, refreshKey]);

  const download = async (s) => {
    try {
      const res = await fetch(API_ENDPOINTS.DOWNLOAD_PROOF(s.id), { headers: authOnly() });
      if (!res.ok) throw new Error('Could not download file');
      const url = URL.createObjectURL(await res.blob());
      const a = document.createElement('a');
      a.href = url; a.download = s.proofFileName || 'proof'; a.click();
      URL.revokeObjectURL(url);
    } catch (err) { toast.error('Error', err.message); }
  };

  const review = async (s, approved) => {
    let comment = '';
    if (!approved) {
      comment = window.prompt('Reason for rejecting (required):') || '';
      if (!comment.trim()) return;
    }
    setBusyId(s.id);
    try {
      await postReview(s.id, approved, comment);
      toast.success(approved ? 'Approved' : 'Rejected', approved ? 'Submission approved' : 'Sent back to employee');
      await load();
      onChanged?.();
    } catch (err) { toast.error('Error', err.message); }
    finally { setBusyId(null); }
  };

  return (
    <div style={{ background: 'var(--card-bg)', border: '1px solid var(--border-light)', borderRadius: 18, overflow: 'hidden' }}>
      <div style={{ padding: '15px 20px', borderBottom: '1px solid var(--border-light)', background: 'var(--bg-surface)' }}>
        <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700 }}>📤 Work Submissions ({list.length})</h3>
      </div>
      <div style={{ padding: 20 }}>
        {loading && <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>Loading…</p>}
        {!loading && list.length === 0 && (
          <div style={{ textAlign: 'center', padding: 24, color: 'var(--text-muted)', fontSize: 13 }}>No work submitted yet.</div>
        )}
        {list.map(s => {
          const [bg, color] = SUB_COLORS[s.status] || ['#f1f5f9', '#475569'];
          return (
            <div key={s.id} style={{ border: '1px solid var(--border-light)', borderRadius: 12, padding: 14, marginBottom: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8, marginBottom: 6 }}>
                <div style={{ fontSize: 13, fontWeight: 700 }}>
                  {(s.employeeName || '').replace(/\s+null\s*/gi, '').trim()}
                  <span style={{ fontWeight: 500, color: 'var(--text-muted)', marginLeft: 8, fontSize: 12 }}>
                    {s.submittedAt ? new Date(s.submittedAt).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }) : ''}
                  </span>
                </div>
                <div style={{ display: 'flex', gap: 6 }}>
                  {s.finalSubmission && <span style={{ background: '#f3e8ff', color: '#5b21b6', padding: '2px 9px', borderRadius: 20, fontSize: 10, fontWeight: 700 }}>FINAL</span>}
                  {s.late && <span style={{ background: '#fee2e2', color: '#991b1b', padding: '2px 9px', borderRadius: 20, fontSize: 10, fontWeight: 700 }}>LATE</span>}
                  <span style={{ background: bg, color, padding: '2px 9px', borderRadius: 20, fontSize: 10, fontWeight: 700 }}>{s.status}</span>
                </div>
              </div>
              <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginBottom: 6 }}>
                Progress <strong>{s.progressPercent ?? 0}%</strong>
                {s.hoursSpent != null && <> · Hours <strong>{s.hoursSpent}</strong></>}
              </div>
              {s.note && <p style={{ margin: '0 0 8px', fontSize: 13.5, color: 'var(--text-secondary)', lineHeight: 1.5 }}>{s.note}</p>}
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
                {s.proofLink && (
                  <a href={s.proofLink} target="_blank" rel="noreferrer" style={{ fontSize: 12, color: 'var(--accent-indigo)', display: 'flex', alignItems: 'center', gap: 4 }}>
                    <FaPaperclip size={10} /> Proof link
                  </a>
                )}
                {s.hasProofFile && (
                  <button onClick={() => download(s)} style={{ background: '#ede9fe', border: 'none', color: 'var(--accent-indigo)', padding: '4px 10px', borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5 }}>
                    <FaDownload size={10} /> {s.proofFileName || 'Download proof'}
                  </button>
                )}
              </div>
              {s.reviewComment && (
                <div style={{ marginTop: 8, fontSize: 12, color: 'var(--text-muted)' }}>
                  Review by {s.reviewedBy}: “{s.reviewComment}”
                </div>
              )}
              {canReview && s.status === 'SUBMITTED' && (
                <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                  <button disabled={busyId === s.id} onClick={() => review(s, true)} style={{ background: 'linear-gradient(135deg,#059669,#10b981)', border: 'none', color: '#fff', padding: '7px 14px', borderRadius: 9, fontWeight: 600, fontSize: 12, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5 }}><FaCheck size={10} /> Approve</button>
                  <button disabled={busyId === s.id} onClick={() => review(s, false)} style={{ background: 'linear-gradient(135deg,#ef4444,#f87171)', border: 'none', color: '#fff', padding: '7px 14px', borderRadius: 9, fontWeight: 600, fontSize: 12, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5 }}><FaTimes size={10} /> Reject</button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
